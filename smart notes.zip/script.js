// Global Variables
let currentUser = null;
let notes = [
    {
        id: 1,
        title: "خطة المشروع الجديد",
        content: "هذه خطة شاملة للمشروع الجديد والتي تتضمن جميع التفاصيل المطلوبة لبدء العمل",
        tags: ["مشروع", "تخطيط", "عمل"],
        isPinned: true,
        createdAt: new Date().toISOString()
    },
    {
        id: 2,
        title: "ملاحظة تجريبية",
        content: "هذه ملاحظة تجريبية لاختبار الموقع. الموقع يعمل بشكل ممتاز!",
        tags: ["تجربة"],
        isPinned: false,
        createdAt: new Date().toISOString()
    },
    {
        id: 3,
        title: "أفكار التطوير",
        content: "مجموعة من الأفكار الإبداعية لتطوير المنتج وتحسين تجربة المستخدم",
        tags: ["أفكار", "تطوير", "إبداع"],
        isPinned: false,
        createdAt: new Date().toISOString()
    },
    {
        id: 4,
        title: "ملاحظات الاجتماع",
        content: "تم مناقشة النقاط التالية في الاجتماع: الجدول الزمني، توزيع المهام على الفريق",
        tags: ["اجتماع", "فريق"],
        isPinned: false,
        createdAt: new Date().toISOString()
    },
    {
        id: 5,
        title: "ملاحظة جديدة",
        content: "اختبار محتوى الملاحظة هنا",
        tags: ["جديد"],
        isPinned: false,
        createdAt: new Date().toISOString()
    }
];

let tasks = [
    {
        id: 1,
        title: "إعداد التقرير الشهري",
        description: "تجميع التقرير الشهري للإنجازات",
        status: "completed",
        priority: "high",
        dueDate: new Date().toISOString(),
        createdAt: new Date().toISOString()
    },
    {
        id: 2,
        title: "تحديث الموقع الإلكتروني",
        description: "إضافة المحتوى الجديد وتحديث التصميم",
        status: "in_progress",
        priority: "medium",
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString()
    },
    {
        id: 3,
        title: "مراجعة التقرير الشهري",
        description: "مراجعة وتدقيق التقرير الشهري قبل إرساله للإدارة",
        status: "review",
        priority: "high",
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString()
    }
];

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const userData = localStorage.getItem('user');
    
    if (isLoggedIn && userData) {
        currentUser = JSON.parse(userData);
        showMainApp();
    } else {
        showLoginPage();
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Load theme
    loadTheme();
}

function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Navigation tabs
    const navTabs = document.querySelectorAll('.nav-tab');
    navTabs.forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });
    
    // Header buttons
    const aiBtn = document.getElementById('aiBtn');
    if (aiBtn) {
        aiBtn.addEventListener('click', toggleAI);
    }
    
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) {
        themeBtn.addEventListener('click', toggleTheme);
    }
    
    const userBtn = document.getElementById('userBtn');
    if (userBtn) {
        userBtn.addEventListener('click', toggleUserMenu);
    }
    
    // AI input
    const aiInput = document.getElementById('aiInput');
    if (aiInput) {
        aiInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendAIMessage();
            }
        });
    }
    
    // Modal forms
    const noteForm = document.getElementById('noteForm');
    if (noteForm) {
        noteForm.addEventListener('submit', handleNoteSubmit);
    }
    
    const taskForm = document.getElementById('taskForm');
    if (taskForm) {
        taskForm.addEventListener('submit', handleTaskSubmit);
    }
    
    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeAllModals();
        }
    });
}

// Authentication
function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    if (username && password) {
        // Simulate login
        currentUser = {
            id: 1,
            username: username,
            email: `${username}@example.com`
        };
        
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('user', JSON.stringify(currentUser));
        
        showMainApp();
    }
}

function logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('user');
    currentUser = null;
    showLoginPage();
}

function showLoginPage() {
    document.getElementById('loginPage').style.display = 'flex';
    document.getElementById('mainApp').style.display = 'none';
}

function showMainApp() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('mainApp').style.display = 'flex';
    
    // Update user display
    const userNameDisplay = document.getElementById('userNameDisplay');
    if (userNameDisplay && currentUser) {
        userNameDisplay.textContent = currentUser.username;
    }
    
    // Load initial data
    renderDashboard();
    renderNotes();
    renderTasks();
}

// Navigation
function switchTab(tabName) {
    // Update nav tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabName).classList.add('active');
    
    // Render content based on tab
    switch(tabName) {
        case 'dashboard':
            renderDashboard();
            break;
        case 'notes':
            renderNotes();
            break;
        case 'tasks':
            renderTasks();
            break;
    }
}

// Dashboard
function renderDashboard() {
    // Update stats
    document.getElementById('notesCount').textContent = notes.length;
    document.getElementById('tasksCount').textContent = tasks.filter(t => t.status === 'completed').length;
    
    // Render recent notes
    const recentNotes = document.getElementById('recentNotes');
    if (recentNotes) {
        recentNotes.innerHTML = notes.slice(0, 3).map(note => `
            <div class="recent-item">
                <h4>${note.title}</h4>
                <p>${note.content.substring(0, 50)}...</p>
            </div>
        `).join('');
    }
    
    // Render upcoming tasks
    const upcomingTasks = document.getElementById('upcomingTasks');
    if (upcomingTasks) {
        upcomingTasks.innerHTML = tasks.filter(t => t.status !== 'completed').slice(0, 3).map(task => `
            <div class="recent-item">
                <h4>${task.title}</h4>
                <p>${task.description.substring(0, 50)}...</p>
            </div>
        `).join('');
    }
}

// Notes
function renderNotes() {
    const notesGrid = document.getElementById('notesGrid');
    if (!notesGrid) return;
    
    notesGrid.innerHTML = notes.map(note => `
        <div class="note-card fade-in">
            <div class="note-header">
                <div>
                    <h3 class="note-title">${note.title}</h3>
                    ${note.isPinned ? '<i class="fas fa-thumbtack" style="color: var(--warning-color);"></i>' : ''}
                </div>
            </div>
            <div class="note-content">${note.content}</div>
            <div class="note-tags">
                ${note.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
            <div class="note-actions">
                <button class="action-btn edit-btn" onclick="editNote(${note.id})">
                    <i class="fas fa-edit"></i> تعديل
                </button>
                <button class="action-btn delete-btn" onclick="deleteNote(${note.id})">
                    <i class="fas fa-trash"></i> حذف
                </button>
                <button class="action-btn ai-btn" onclick="aiNoteAction(${note.id})">
                    <i class="fas fa-robot"></i> AI
                </button>
            </div>
        </div>
    `).join('');
}

function openNoteModal() {
    document.getElementById('noteModal').classList.add('show');
}

function closeNoteModal() {
    document.getElementById('noteModal').classList.remove('show');
    document.getElementById('noteForm').reset();
}

function handleNoteSubmit(e) {
    e.preventDefault();
    
    const title = document.getElementById('noteTitle').value;
    const content = document.getElementById('noteContent').value;
    const tagsInput = document.getElementById('noteTags').value;
    const tags = tagsInput ? tagsInput.split(',').map(tag => tag.trim()) : [];
    
    const newNote = {
        id: Date.now(),
        title,
        content,
        tags,
        isPinned: false,
        createdAt: new Date().toISOString()
    };
    
    notes.unshift(newNote);
    renderNotes();
    renderDashboard();
    closeNoteModal();
    
    // Show success message
    showNotification('تم إنشاء الملاحظة بنجاح!', 'success');
}

function deleteNote(id) {
    if (confirm('هل أنت متأكد من حذف هذه الملاحظة؟')) {
        notes = notes.filter(note => note.id !== id);
        renderNotes();
        renderDashboard();
        showNotification('تم حذف الملاحظة بنجاح!', 'success');
    }
}

function editNote(id) {
    const note = notes.find(n => n.id === id);
    if (note) {
        document.getElementById('noteTitle').value = note.title;
        document.getElementById('noteContent').value = note.content;
        document.getElementById('noteTags').value = note.tags.join(', ');
        openNoteModal();
        
        // Update form to edit mode
        const form = document.getElementById('noteForm');
        form.onsubmit = function(e) {
            e.preventDefault();
            
            note.title = document.getElementById('noteTitle').value;
            note.content = document.getElementById('noteContent').value;
            const tagsInput = document.getElementById('noteTags').value;
            note.tags = tagsInput ? tagsInput.split(',').map(tag => tag.trim()) : [];
            
            renderNotes();
            renderDashboard();
            closeNoteModal();
            
            // Reset form handler
            form.onsubmit = handleNoteSubmit;
            showNotification('تم تحديث الملاحظة بنجاح!', 'success');
        };
    }
}

// Tasks
function renderTasks() {
    const tasksGrid = document.getElementById('tasksGrid');
    if (!tasksGrid) return;
    
    tasksGrid.innerHTML = tasks.map(task => `
        <div class="task-card fade-in">
            <div class="task-header">
                <h3 class="task-title">${task.title}</h3>
                <div class="task-priority priority-${task.priority}">${getPriorityText(task.priority)}</div>
            </div>
            <div class="task-status status-${task.status}">${getStatusText(task.status)}</div>
            <div class="task-description">${task.description}</div>
            <div class="task-due">
                <i class="fas fa-calendar"></i>
                ${new Date(task.dueDate).toLocaleDateString('ar-SA')}
            </div>
            <div class="task-actions">
                <button class="action-btn edit-btn" onclick="editTask(${task.id})">
                    <i class="fas fa-edit"></i> تعديل
                </button>
                <button class="action-btn delete-btn" onclick="deleteTask(${task.id})">
                    <i class="fas fa-trash"></i> حذف
                </button>
                <button class="action-btn ai-btn" onclick="aiTaskAction(${task.id})">
                    <i class="fas fa-robot"></i> AI
                </button>
            </div>
        </div>
    `).join('');
}

function openTaskModal() {
    document.getElementById('taskModal').classList.add('show');
}

function closeTaskModal() {
    document.getElementById('taskModal').classList.remove('show');
    document.getElementById('taskForm').reset();
}

function handleTaskSubmit(e) {
    e.preventDefault();
    
    const title = document.getElementById('taskTitle').value;
    const description = document.getElementById('taskDescription').value;
    const priority = document.getElementById('taskPriority').value;
    const dueDate = document.getElementById('taskDueDate').value;
    
    const newTask = {
        id: Date.now(),
        title,
        description,
        status: 'pending',
        priority,
        dueDate: dueDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString()
    };
    
    tasks.unshift(newTask);
    renderTasks();
    renderDashboard();
    closeTaskModal();
    
    showNotification('تم إنشاء المهمة بنجاح!', 'success');
}

function deleteTask(id) {
    if (confirm('هل أنت متأكد من حذف هذه المهمة؟')) {
        tasks = tasks.filter(task => task.id !== id);
        renderTasks();
        renderDashboard();
        showNotification('تم حذف المهمة بنجاح!', 'success');
    }
}

function editTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        document.getElementById('taskTitle').value = task.title;
        document.getElementById('taskDescription').value = task.description;
        document.getElementById('taskPriority').value = task.priority;
        document.getElementById('taskDueDate').value = task.dueDate.split('T')[0];
        openTaskModal();
        
        // Update form to edit mode
        const form = document.getElementById('taskForm');
        form.onsubmit = function(e) {
            e.preventDefault();
            
            task.title = document.getElementById('taskTitle').value;
            task.description = document.getElementById('taskDescription').value;
            task.priority = document.getElementById('taskPriority').value;
            task.dueDate = document.getElementById('taskDueDate').value;
            
            renderTasks();
            renderDashboard();
            closeTaskModal();
            
            // Reset form handler
            form.onsubmit = handleTaskSubmit;
            showNotification('تم تحديث المهمة بنجاح!', 'success');
        };
    }
}

function getPriorityText(priority) {
    const priorities = {
        'high': 'عالية',
        'medium': 'متوسطة',
        'low': 'منخفضة'
    };
    return priorities[priority] || priority;
}

function getStatusText(status) {
    const statuses = {
        'pending': 'في الانتظار',
        'in_progress': 'قيد التنفيذ',
        'completed': 'مكتملة',
        'review': 'قيد المراجعة'
    };
    return statuses[status] || status;
}

// AI Functions
function toggleAI() {
    const aiSidebar = document.getElementById('aiSidebar');
    aiSidebar.classList.toggle('open');
}

function closeAI() {
    document.getElementById('aiSidebar').classList.remove('open');
}

function sendAIMessage(message = null) {
    const input = document.getElementById('aiInput');
    const messageText = message || input.value.trim();
    
    if (!messageText) return;
    
    // Add user message
    addAIMessage(messageText, true);
    
    // Clear input
    if (!message) {
        input.value = '';
    }
    
    // Simulate AI response
    setTimeout(() => {
        const response = generateAIResponse(messageText);
        addAIMessage(response, false);
    }, 1000);
}

function addAIMessage(message, isUser) {
    const messagesContainer = document.getElementById('aiMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ${isUser ? 'user-message' : ''}`;
    
    messageDiv.innerHTML = `
        <div class="ai-avatar">${isUser ? 'أ' : '🤖'}</div>
        <div class="message-content">${message}</div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function generateAIResponse(message) {
    if (message.includes('نصائح') || message.includes('الإنتاجية')) {
        return `إليك بعض النصائح لتحسين الإنتاجية:

1. **تنظيم الوقت**: استخدم تقنية البومودورو (25 دقيقة عمل + 5 دقائق راحة)
2. **ترتيب الأولويات**: ركز على المهام الأهم أولاً
3. **تجنب التشتت**: أغلق الإشعارات غير الضرورية
4. **خذ فترات راحة**: الراحة تزيد من التركيز
5. **استخدم الأدوات المناسبة**: مثل هذا التطبيق لتنظيم ملاحظاتك ومهامك

هل تريد نصائح أكثر تفصيلاً في أي من هذه النقاط؟`;
    } else if (message.includes('تلخيص') || message.includes('لخص')) {
        return `سأساعدك في تلخيص المحتوى:

**الملخص:**
- النقاط الرئيسية من النص
- الأفكار المهمة
- التوصيات والخطوات التالية

لتلخيص أفضل، يرجى مشاركة النص المراد تلخيصه.`;
    } else if (message.includes('مهمة') || message.includes('مهام')) {
        return `إليك اقتراحات لإدارة المهام بفعالية:

**تنظيم المهام:**
- قسم المهام الكبيرة إلى مهام أصغر
- حدد موعد نهائي واقعي لكل مهمة
- استخدم نظام الأولويات (عالية، متوسطة، منخفضة)

**متابعة التقدم:**
- راجع المهام يومياً
- احتفل بإنجاز المهام المكتملة
- عدّل الخطط حسب الحاجة

هل تريد مساعدة في تنظيم مهمة معينة؟`;
    } else {
        return `شكراً لك على رسالتك! 

أنا مساعد ذكي مصمم لمساعدتك في:
- تنظيم الملاحظات والمهام
- تحسين الإنتاجية
- تلخيص المحتوى
- إعطاء نصائح عملية

كيف يمكنني مساعدتك اليوم؟ يمكنك أن تسأل عن:
- نصائح لتحسين الإنتاجية
- طرق تنظيم المهام
- كيفية كتابة ملاحظات فعالة
- تلخيص النصوص`;
    }
}

function aiNoteAction(noteId) {
    const note = notes.find(n => n.id === noteId);
    if (note) {
        toggleAI();
        setTimeout(() => {
            sendAIMessage(`لخص لي هذه الملاحظة: "${note.title}" - ${note.content}`);
        }, 500);
    }
}

function aiTaskAction(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        toggleAI();
        setTimeout(() => {
            sendAIMessage(`اعطني نصائح لإنجاز هذه المهمة: "${task.title}" - ${task.description}`);
        }, 500);
    }
}

// Theme Functions
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update theme button icon
    const themeBtn = document.getElementById('themeBtn');
    const icon = themeBtn.querySelector('i');
    icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}

function loadTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    // Update theme button icon
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) {
        const icon = themeBtn.querySelector('i');
        icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

// User Menu
function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('show');
}

// Close user menu when clicking outside
document.addEventListener('click', function(e) {
    const userMenu = document.querySelector('.user-menu');
    if (!userMenu.contains(e.target)) {
        document.getElementById('userDropdown').classList.remove('show');
    }
});

// Modal Functions
function closeAllModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('show');
    });
}

// Notification System
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success-color);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: var(--shadow-lg);
        z-index: 3000;
        animation: slideIn 0.3s ease-out;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add CSS for notification animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

